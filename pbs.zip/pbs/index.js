const express = require('express');
const bodyParser = require('body-parser');
const db = require('./config.js')
const app = express();
const port = 3002;

// Middleware for parsing JSON bodies
app.use(bodyParser.json());

app.get('/mahasiswa', (req,res)=>{
    db.query('SELECT * FROM tb_mahasiswa',(error, result)=>{
        console.log(result)
        res.send(result)
    })
})
app.post('/data', (req, res) => {
  console.log({ RequestFromOutside: req.body });
  res.send('Login berhasil');
});

app.listen(port, () => {
  console.log('Running in port ${port}');
});